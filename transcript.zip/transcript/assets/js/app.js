// JavaScript Document

/*@
 * this blocks of code works on the user login system 
 * using ajax
 */
$('#form_login').on('submit', function(e){
	 
	
	
	if($('#email').val() === '' || $('#account_type').val()=== 'Select Account Type' || $('#password').val()=== ''){
		
		e.preventDefault();
		
		$('#feedback').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> please all field are required</div>');
		
     }else{
		   $('#feedback').html('');
		   e.preventDefault();
		   
		    console.log($('#email').val());
	        console.log($('#password').val());
	        console.log($('#account_type').val());
		  
		  $.ajax({
			  
			  url : baseURL + 'auth/login',
			  type:'POST',
			  data: $('#form_login').serialize(),
			  success: function(data){
				     
					 if(data === 'error'){
						 
						    
					 $('#feedback').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> Invalid Email and Password Combination</div>');
					 console.log(data);
							
						 
						 }else{
							    
								window.location = data;
							 
							 }
				  
				  }
			  
			  
			  
			  
			  }); 
		    
		 
		 }
	
		
		
 })
 

 
 $('#form_add_course').on('submit', function(e){
	 
	   //call the add course function 
	   add_course_details(e);
	 
  });
  
  
  
  //this function adds course details
  function add_course_details(e)
  {
	  
        if($('#course_title').val()==='' || $('#course_code').val()==='' || $('#credits').val()==='' || $('#level').val()==='Select Level' || $('#semester').val()==='Select Semester' ){
			
			  e.preventDefault();
			  
			  console.log($('#course_title').val());
			  console.log($('#course_code').val());
			  console.log($('#credits').val());
			  console.log($('#level').val());
			  console.log($('#semester').val());
			  
			  $('#feedback_add_course').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> All fields are required</div>');
			
			}else{
				    
				  e.preventDefault();
				  
				  $.ajax({
					  
				  	    url : baseURL + 'admin/dashboard/add_course',
			            type:'POST',
			            data: $('#form_add_course').serialize(),
			            success: function(data){
							
							if(data === 'inserted'){
								     
									 $('#form_add_course').trigger('reset');
								     $('#feedback_add_course').html('<div class="alert alert-success" role="alert"><i class="fa fa-close"></i> Course detail successfuly Added</div>');
								setTimeout("$('#feedback_add_course').html('')", 5000); 
								}else{
									
									   //display an error
									   alert("error");
									
									}
							
						     }
				     
					  
					  
					  });
				
				}
  
  }
 
 
 
 
 //////////////////////////////////////////////////////////////////////////////
 
 /*@
 * this is method add drugs in the pharmacy dashboard
 * using ajax
 */
 
  $('#form_add_student').on('submit', function(e){
	  
	  
	  if($('#student_name').val() === '' || $('#reg_num').val() === '' || $('#dept').val() === '' || $('#faculty').val() === '' || $('#date_admit').val() === ''){
		  
		  e.preventDefault();
		  $('#feedback_add_student').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> please all field are required</div>');
		  
		}else{
			  
			    e.preventDefault();
			    $.ajax({
					
					    url  : baseURL + 'lecturer/dashboard/add_student',
						type :'POST',
						data : $('#form_add_student').serialize(),
						success: function(result){
				     
					         if(result === 'inserted'){
								     
									
									$('#form_add_student').trigger('reset');
								   $('#feedback_add_student').html('<div class="alert alert-success" role="alert"><i class="fa fa-check"></i> Student Details Added successfuly</div>');
								   setTimeout("$('#modal_add_student').modal('hide')", 4000); 
								   setTimeout("$('#feedback_add_student').html('')", 3000); 
								   console.log(result);
								 
								}else{
									   $('#feedback_add_student').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> Some Error ocurred</div>');		
									   							
									}
				  
				        }
						
					
					});
			   
			  
			   	
			}
	   
  })
  
  
  

  //this java script code adds lecturer
  
  $('#form_add_lecturer').on('submit', function(e){
	  
	  
	  if($('#lecturer_name').val() === '' || $('#level').val() === '' || $('#dept').val() === '' || $('#uname').val() === '' || $('#password').val() === ''){
		  
		  e.preventDefault();
		  $('#feedback_add_lecturer').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> please all field are required</div>');
		  
		  
		}else{
			  
			    e.preventDefault();
			    $.ajax({
					
					    url  : baseURL + 'admin/dashboard/add_lecturer',
						type :'POST',
						data : $('#form_add_lecturer').serialize(),
						success: function(result){
				     
					         if(result === 'inserted'){
								     
									
									$('#form_add_lecturer').trigger('reset');
								   $('#feedback_add_lecturer').html('<div class="alert alert-success" role="alert"><i class="fa fa-check"></i> Lecturer Registered successfuly</div>');
								   setTimeout("$('#modal_add_lecturer').modal('hide')", 4000);
								   setTimeout("$('#feedback_add_lecturer').html('')", 3000); 
								    
								   console.log(result);
								 
								}else{
									   $('#feedback_add_lecturer').html('<div class="alert alert-danger" role="alert"><i class="fa fa-close"></i> Some Error ocurred</div>');		
									   							
									}
				  
				        }
						
					
					});
			   
			  
			   	
			}
	   
  })
  
  
  
  
  //this block of code validate the study year and display the result form
  $('#study_year').on('change', function(e){
	  
	   if($(this).val() === 'Select Study Year'){
		   
		   e.preventDefault();
		   
		    $('#result_table').addClass('display-result-table');
		   
		  }else{
			  
			    $('#result_table').removeClass('display-result-table');
			  
			  }  
	  
	});
  
  
  
  
   
/*//////////////////////////////////////////////////////////////////////////////
  The code for the first semester result table STARTS here   START.....
  
//////////////////////////////////////////////////////////////////////////////*/

 //this BLOCK of code adds new row for first semester
 
    var i=1;
	 
	 
	$('#add_btn_first').on('click', function(){
		
		//showing the hidden save button
		$('#save_first').show();
		
		
		 count = $('#new_row_first tr').length;
     var html = '';
	     html += '<tr class="row_id" id="delete_first'+i+'">';
		 html += '<td>'+ i +'</td>';
		 
		 
		 html += '<td><select class="form-control course_id_first" name="course_first'+i+'" id="course_first'+i+'">';
		 html += '<option>Select Course Code</option>';
		 html += drop_down_first('course_first'+i, 'title_first'+i, 'credits_first'+i, 'grade_first'+i, 'num_grade_first'+i, 'point_earn_first'+i);
		 html += '</select></td>';
		 html += '<td id="title_first'+i+'"></td>';
		 html += '<td class="add_credit_first" id="credits_first'+i+'"></td>';
		  
		 html += '<td><select class="form-control" id="grade_first'+i+'" >';
		 html += '<option>Select Grade</option>';
		 html += drop_down_grades_first();
		 html += '</select></td>';
		 
		 
		 
		 html += '<td class="grade_point_first" id="num_grade_first'+i+'"></td>';
		 
		 
		 html += '<td class="add_point_first point_earn_first" id="point_earn_first'+i+'"></td>';
		 html += '<td><button type="button" onClick="delete_row(\'delete_first'+i+'\');" class="btn btn-danger btn-sm"><i class="fa fa-remove (alias)"></i></button></td>';
		 html += '</tr>';
	 	 
		 $('#new_row_first').append(html);
		 i++;

		 //console.log(html);
		
	}) 
	
  
  
  

	//this method saves the first semester transcript  
   $('#save_first').click(function(e){
	 
	   $('#save_first').slideUp();
	   
	   var course_id = [];
	   var grade_point = [];
	   var point_earn = [];
	   
	   $('.course_id_first').each(function(){
		   
		   course_id.push($(this).val());
		   
	    });
		
		$('.grade_point_first').each(function(){
		   
		   grade_point.push($(this).text());
		   
	    });
		
		$('.point_earn_first').each(function(){
		   
		   point_earn.push($(this).text());
		   
	    }); 
		
		
		var student_id  = $('#student_id').val();
		var level_id    = $('#study_year').val();
		var semester_id =  $('#semester_id').val();
		
		//console.log("course_id : "+course_id);
	    //console.log("grade_point : "+grade_point);
	    //console.log("point_earn : "+point_earn);
		
		$.ajax({
			
			  url:baseURL + 'lecturer/dashboard/save_transcript_first',
			  type:'POST',
			  data:{
				   
				   student_id : student_id,
				   level_id : level_id,
				   course_id :course_id,
				   grade_point : grade_point,
				   point_earn : point_earn,
				   semester_id : semester_id,
				  },
		     success: function(data){
				 
			    if(data === 'inserted'){
					
					   //this function insert insert_credit_load, gpa of student
					   insert_credit_load();
					
					}else{
						
						//dislplay error
						
						}
			 
			  }		  
			
			});
		
	   
	});


  //this function adds_the students semester total credit point
  function insert_credit_load()
  {
	  
	  //getting the required info
	  var student_id  = $('#student_id').val();
	  var level_id    = $('#study_year').val();
	  var semester_id =  $('#semester_id').val();
      
	  //getting the total credit load of the student
	  var credit = 0;
	  $('table td.add_credit_first').each(function(index, td){
		 
		     credit += parseInt(Number($(td).text()));
			 
			
		    
			 
		 });
		 
		 console.log('total_credit_load : '+credit);
		 
	  //getting the total grade point of the student
	  var point = 0;
	  $('table td.add_point_first').each(function(index, th){
		 
		     point += parseInt(Number($(th).text()));
			 
			 
		     
			 
		 });	 
	   console.log('total_point_earn : '+point);
	  
	  
	   //getting the total gpa
		var student_gpa = point / credit;
		console.log('student_point : '+parseFloat(student_gpa).toFixed(2));
		
		//send it to the sever using ajax
		$.ajax({
			
			url:baseURL +"lecturer/dashboard/insert_total_point",
			type:"POST",
			data : {
				  
				  semester_id : semester_id, 
				  level_id    : level_id, 
				  student_id  : student_id, 
				  credit      : credit, 
				  point       : point, 
				  student_gpa : parseFloat(student_gpa).toFixed(2) 
				  },
			success: function(data){
				
				//response here
				  if(data === 'inserted'){
					    
						//update student info
					     update_student_info(student_id, credit, point);
					  
					 }
				}
			
			});
	  
  
  }

   
   
   //this method updates the students info cgpa, total credit load, total point
   function update_student_info(student_id, credit, point)
   {
	     
      $.ajax({
		  
		  url:baseURL + "lecturer/dashboard/update_student_info",
		  type:"POST",
		  data:{student_id:student_id, credit:credit, point:point },
		  success: function(res){
			     
				 //success message 
				 if(res === 'Student inserted'){
					 
					     console.log(res);
						 
						 //fadeout the table
					     $('#new_row_first').fadeOut(2000);
						 $('#first_semester_table').html('<div class="alert alert-success" role="alert"><i class="fa fa-check"></i> First Semester Transcript Saved Succesfully</div>');
						 $('#save_first').slideDown();
						
					 }else{
						    
						   console.log(res);
						 } 
			  
			  }
		  
		  });
   
   }
 
 
  //this method gets dropdown for course code
   function drop_down_first(id, title, credits, grade, num_grade, point_earn)
   {  
   
          //console.log(id);
		 // console.log('title: '+title);
		  //console.log('credits: '+credits);
		  
		  var semester = 1;
		  
        
	     $.ajax({
		
		  url: baseURL + 'lecturer/dashboard/dropdown',
		  type: 'POST',
		  data: {semester:semester},
		  success: function(data){
				   
				//$('#list_contestant').html(data);
				  if(data === 'error'){
					  
					    //$('#'+id).html();
						//console.log(data);
					  
					  }else{
						  
						    //$('#'+id).html();
							$('#'+id).append(data);
							//console.log(data);
						    
							//this method gets course titile
							get_course_title_first(id, title, credits);
							
							//method for grade calulate
						     grade_settings_first(credits, grade, num_grade, point_earn);
							
							//this method saves first semester result 
							//save_first_semester(id, grade, point_earn)
							
						  }
				    
				}
		
		});
	   
	  
   }
   
   
   
   
   
   //this method gets dropdown for grades A,B,C,D
   function drop_down_grades_first()
   {
	    var html = '';
	        html += '<option value="A">A</option>';
			html += '<option value="B">B</option>';
			html += '<option value="C">C</option>';
			html += '<option value="D">D</option>';
			html += '<option value="F">F</option>';
			
			return html;
            //console.log(html);
  } 
   
   
   
   
   
   
   //THIS method adds course from the database
   function get_course_title_first(id, title, credits)
   {    
        
		    $('#'+id).change(function(){
				
				var course_id = $(this).val();
		        //console.log(course_id);
				
				
				$.ajax({
					
			           
				  url : baseURL + 'lecturer/dashboard/get_course_title',
			      type:'POST',
				  dataType:"json",
			      data:{course_id:course_id},
				  success: function(data){
					  
				          //console.log(data);	
						  //console.log((data.course_title));
						   //console.log((data.credits));
						  $('#'+title).html(data.course_title); 
						  $('#'+credits).html(parseInt(data.credits)); 
						   
						   //count total credit load
	                       add_credits_first();  
					      
						  
						  
					
					  }
				   		
					
				 });
			
				
			 });
	    
		 
	   
   }
   
   
   
   
   //this method gets and calculate the users grade
   function grade_settings_first(credits, grade, num_grade, point_earn)
   {    
       $('#'+grade).change(function(){
		   
		  var grade_input = $(this).val();
		   
		   
		    var grade_value = ''; 
		
	      if(grade_input === 'A'){
			  
			     grade_value   = 5;
			  
			  }else if(grade_input === 'B'){
				  
				    
				  grade_value   = 4;
				  
				  
				  }else if(grade_input === 'C'){
					  
					  
					    grade_value   = 3;
					  
					  }else if(grade_input === 'D'){
						  
						  grade_value   = 2;
						  
						  
						  }else{
							  
							  grade_value   = 0;
							  
							  }
			  
			  
			       //updating the number grade equvilent
			      $('#'+num_grade).html(grade_value);
				  
				  
				  //getting the credits value of a course 
				  var course_credit = $('#'+credits).text();
				 // console.log('course_credit : '+course_credit);
				  
				  
		          //caluclating point earn
				  var point_en = grade_value * course_credit;
				  
				  
				  //update point earn
				  $('#'+point_earn).html(point_en);
			      
				  //displaying points earned
			      add_point_first();
				  
				  
				  //display gpa
				  calculate_gpa_first();
		});

   }
   
   
   
  //dis method delete a row
 function delete_row(id)
 {
	 
    $('#'+id).remove();
	return false;
 
 }
 
 
 

 
 
 
 //this method adds up all colum
 function add_credits_first()
 {
	 var total = 0;
	 
	 $('table td.add_credit_first').each(function(index, td){
		 
		     total += parseInt(Number($(td).text()));
			 
			// console.log('total_credit_load : '+total);
		     $('#total_credit_first').text(total);
			 
		 });
 }
 
 
 
 
 
 
  function add_point_first()
 {
	 var total = 0;
	 
	 $('table td.add_point_first').each(function(index, td){
		 
		     total += parseInt(Number($(td).text()));
			 
			// console.log('total_credit_load : '+total);
		     $('#total_point_first').text(total);
			 
		 });
 }
 
 
 
 function calculate_gpa_first()
 {
	 
    //getting the point earn
	 var point = 0;
	 
	 $('table td.add_point_first').each(function(index, td){
		 
		     point += parseInt(Number($(td).text()));
			 
			// console.log('total_credit_load : '+total);
		     //$('#total_point').text(total);
			 
		 });
		 
		 
		 
		 
		 //getting credit load 
		  var credit = 0;
	 
	 $('table td.add_credit_first').each(function(index, th){
		 
		     credit += parseInt(Number($(th).text()));
			 
			// console.log('total_credit_load : '+total);
		     //$('#total_credit').text(total);
			 
		 });
		 
		 
		 //getting the gpa
		 var student_point = point / credit;
		 //console.log('student_point : '+parseFloat(student_point).toFixed(2));
		 $('#gpa_first').text(parseFloat(student_point).toFixed(2));
 
 
 }
 
 
 
   
 //this blocks of code hides the button when the page loads
 $(document).ready(function(e) {
    
	$('#save_first, #save_second').hide();
}); 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
/*//////////////////////////////////////////////////////////////////////////////
  The code for the first semester result table ends here   END.....
  
//////////////////////////////////////////////////////////////////////////////*/
 
 //////////////////////////////////////////////////////////////////////////////////////////////////////
 

/*//////////////////////////////////////////////////////////////////////////////
  The code for the Second semester result table STARTS here   STARTS.....
  
//////////////////////////////////////////////////////////////////////////////*/ 
 
 
 
 
 //this BLOCK of code adds new row for second semester
 
    var r=1;
	 
	 
	$('#add_btn_second').on('click', function(){
		
		 //showing the hidden save button
		 $('#save_second').show();
		 
		 count = $('#new_row_second tr').length;
     var tab = '';
	     tab += '<tr id="delete_second'+r+'">';
		 tab += '<td>'+ r +'</td>';
		 
		 //html += '<td><select class="form-control" name="'+i+'" id="'+i+'" >'+drop_down(i)+'</select></td>';
		 tab += '<td><select select class="form-control course_id_second" name="course_second'+r+'" id="course_second'+r+'">';
		 tab += '<option>Select Course Code</option>';
		 tab += drop_down_second('course_second'+r, 'title_second'+r, 'credits_second'+r, 'grade_second'+r, 'num_grade_second'+r, 'point_earn_second'+r);
		 tab += '</select></td>';
		 tab += '<td id="title_second'+r+'"></td>';
		 tab += '<td class="add_credit_second" id="credits_second'+r+'"></td>';
		  
		 tab += '<td><select class="form-control" id="grade_second'+r+'" >';
		 tab += '<option>Select Grade</option>';
		 tab += drop_down_grades_second();
		 tab += '</select></td>';
		 
		 
		 
		 tab += '<td class="grade_point_second" id="num_grade_second'+r+'"></td>';
		 
		 
		 tab += '<td class="add_point_second point_earn_second" id="point_earn_second'+r+'"></td>';
		 tab += '<td><button type="button" onClick="delete_row(\'delete_second'+r+'\');" class="btn btn-danger btn-sm"><i class="fa fa-remove (alias)"></i></button></td>';
		 tab += '</tr>';
	 	 
		 $('#new_row_second').append(tab);
		 r++;

		 
		
	}) 
	
  
 
 
    

	//this method saves the first semester transcript  
   $('#save_second').click(function(){
	   
	   $('#save_second').slideUp();
	   
	   var course_id = [];
	   var grade_point = [];
	   var point_earn = [];
	   
	   $('.course_id_second').each(function(){
		   
		   course_id.push($(this).val());
		   
	    });
		
		$('.grade_point_second').each(function(){
		   
		   grade_point.push($(this).text());
		   
	    });
		
		$('.point_earn_second').each(function(){
		   
		   point_earn.push($(this).text());
		   
	    }); 
		
		
		var student_id  = $('#student_id').val();
		var level_id    = $('#study_year').val();
		var semester_id =  $('#semester_id_second').val();
		
		//console.log("course_id : "+course_id);
	    //console.log("grade_point : "+grade_point);
	    //console.log("point_earn : "+point_earn);
		
		$.ajax({
			
			  url:baseURL + 'lecturer/dashboard/save_transcript_first',
			  type:'POST',
			  data:{
				   
				   student_id : student_id,
				   level_id : level_id,
				   course_id :course_id,
				   grade_point : grade_point,
				   point_earn : point_earn,
				   semester_id : semester_id,
				  },
		     success: function(data){
				 
			    if(data === 'inserted'){
					
					   //this function insert insert_credit_load, gpa of student
					   insert_credit_load_second();
					
					}else{
						
						//dislplay error
						
						}
			 
			  }		  
			
			});
		
	   
	});


  //this function adds_the students semester total credit point
  function insert_credit_load_second()
  {
	  
	  //getting the required info
	  var student_id  = $('#student_id').val();
	  var level_id    = $('#study_year').val();
	  var semester_id =  $('#semester_id_second').val();
      
	  //getting the total credit load of the student
	  var credit = 0;
	  $('table td.add_credit_second').each(function(index, td){
		 
		     credit += parseInt(Number($(td).text()));
			 
			
		    
			 
		 });
		 
		 console.log('total_credit_load_second : '+credit);
		 
	  //getting the total grade point of the student
	  var point = 0;
	  $('table td.add_point_second').each(function(index, th){
		 
		     point += parseInt(Number($(th).text()));
			 
			 
		     
			 
		 });	 
	   console.log('total_point_earn_second : '+point);
	  
	  
	   //getting the total gpa
		var student_gpa = point / credit;
		console.log('student_point_second : '+parseFloat(student_gpa).toFixed(2));
		
		//send it to the sever using ajax
		$.ajax({
			
			url:baseURL +"lecturer/dashboard/insert_total_point",
			type:"POST",
			data : {
				  
				  semester_id : semester_id, 
				  level_id    : level_id, 
				  student_id  : student_id, 
				  credit      : credit, 
				  point       : point, 
				  student_gpa : parseFloat(student_gpa).toFixed(2) 
				  },
			success: function(data){
				
				//response here
				  if(data === 'inserted'){
					    
						//update student info
					     update_student_info_second(student_id, credit, point);
					  
					 }
				}
			
			});
	  
  
  }

   
   
   //this method updates the students info cgpa, total credit load, total point
   function update_student_info_second(student_id, credit, point)
   {
	     
      $.ajax({
		  
		  url:baseURL + "lecturer/dashboard/update_student_info",
		  type:"POST",
		  data:{student_id:student_id, credit:credit, point:point },
		  success: function(res){
			     
				 //success message 
				 if(res === 'Student inserted'){
					 
					     console.log("second "+res);
						 //fadeout the table
					     $('#new_row_second').fadeOut(2000);
						  $('#second_semester_table').html('<div class="alert alert-success" role="alert"><i class="fa fa-check"></i> Second Semester Transcript Saved Succesfully</div>');
						 $('#save_second').slideDown();
					
						
					 }else{
						    
						   console.log(res);
						 } 
			  
			  }
		  
		  });
   
   }
 
 
 
 
 
 
 
 
  //this method gets dropdown for course code
   function drop_down_second(id, title, credits, grade, num_grade, point_earn)
   {  
   
          //console.log(id);
		 // console.log('title: '+title);
		  //console.log('credits: '+credits);
		  var semester = 2;
        
	     $.ajax({
		
		  url: baseURL + 'lecturer/dashboard/dropdown',
		  type: 'POST',
		  data: {semester:semester},
		  success: function(data){
				   
				//$('#list_contestant').html(data);
				  if(data === 'error'){
					  
					    //$('#'+id).html();
						//console.log(data);
					  
					  }else{
						  
						    //$('#'+id).html();
							$('#'+id).append(data);
							//console.log(data);
						    
							//this method gets course titile
							get_course_title_second(id, title, credits);
							
							//method for grade calulate
						     grade_settings_second(credits, grade, num_grade, point_earn);
							
							
							
						  }
				    
				}
		
		});
	   
	  
   }
   
   
   
   
   
   //this method gets dropdown for grades A,B,C,D
   function drop_down_grades_second()
   {
	    var html = '';
	        html += '<option value="A">A</option>';
			html += '<option value="B">B</option>';
			html += '<option value="C">C</option>';
			html += '<option value="D">D</option>';
			html += '<option value="F">F</option>';
			
			return html;
            //console.log(html);
  } 
   
   
   
   
   
   
   
   //THIS method adds course from the database
   function get_course_title_second(id, title, credits)
   {    
        
		    $('#'+id).change(function(){
				
				var course_id = $(this).val();
		        //console.log(course_id);
				
				
				$.ajax({
					
			           
				  url : baseURL + 'lecturer/dashboard/get_course_title',
			      type:'POST',
				  dataType:"json",
			      data:{course_id:course_id},
				  success: function(data){
					  
				          //console.log(data);	
						  //console.log((data.course_title));
						   //console.log((data.credits));
						  $('#'+title).html(data.course_title); 
						  $('#'+credits).html(parseInt(data.credits)); 
						   
						   //count total credit load
	                       add_credits_second();  
					      
						  
						  
					
					  }
				   		
					
				 });
			
				
			 });
	    
		 
	   
   }
   
   
   
   
   //this method gets and calculate the users grade
   function grade_settings_second(credits, grade, num_grade, point_earn)
   {    
       $('#'+grade).change(function(){
		   
		  var grade_input = $(this).val();
		   
		   
		    var grade_value = ''; 
		
	      if(grade_input === 'A'){
			  
			     grade_value   = 5;
			  
			  }else if(grade_input === 'B'){
				  
				    
				  grade_value   = 4;
				  
				  
				  }else if(grade_input === 'C'){
					  
					  
					    grade_value   = 3;
					  
					  }else if(grade_input === 'D'){
						  
						  grade_value   = 2;
						  
						  
						  }else{
							  
							  grade_value   = 0;
							  
							  }
			  
			  
			       //updating the number grade equvilent
			      $('#'+num_grade).html(grade_value);
				  
				  
				  //getting the credits value of a course 
				  var course_credit = $('#'+credits).text();
				 // console.log('course_credit : '+course_credit);
				  
				  
		          //caluclating point earn
				  var point_en = grade_value * course_credit;
				  
				  
				  //update point earn
				  $('#'+point_earn).html(point_en);
			      
				  //displaying points earned
			      add_point_second();
				  
				  
				  //display gpa
				  calculate_gpa_second();
		});
	  
	  
	
   }
   
   
 
 
  
 //this method adds up all creddit load of a course
 function add_credits_second()
 {
	 var total = 0;
	 
	 $('table td.add_credit_second').each(function(index, td){
		 
		     total += parseInt(Number($(td).text()));
			 
			// console.log('total_credit_load : '+total);
		     $('#total_credit_second').text(total);
			 
		 });
 }
 
 
 
 
 
  //this method adds up the point earn
  function add_point_second()
 {
	 var total = 0;
	 
	 $('table td.add_point_second').each(function(index, td){
		 
		     total += parseInt(Number($(td).text()));
			 
			// console.log('total_credit_load : '+total);
		     $('#total_point_second').text(total);
			 
		 });
 }
 
 
 
 //this method calculate total gpa
 function calculate_gpa_second()
 {
	 
    //getting the point earn
	 var point = 0;
	 
	 $('table td.add_point_second').each(function(index, td){
		 
		     point += parseInt(Number($(td).text()));
			 
			// console.log('total_credit_load : '+total);
		     //$('#total_point').text(total);
			 
		 });
		 
		 
		 
		 
		 //getting credit load 
		  var credit = 0;
	 
	 $('table td.add_credit_second').each(function(index, th){
		 
		     credit += parseInt(Number($(th).text()));
			 
			// console.log('total_credit_load : '+total);
		     //$('#total_credit').text(total);
			 
		 });
		 
		 
		 //getting the gpa
		 var student_point = point / credit;
		 //console.log('student_point : '+parseFloat(student_point).toFixed(2));
		 $('#gpa_second').text(parseFloat(student_point).toFixed(2));
 
 }
 
 
 
/*//////////////////////////////////////////////////////////////////////////////
  The code for the Second semester result table ENDS here   END.....
  
//////////////////////////////////////////////////////////////////////////////*/ 
 
 
 
 //////////////////////////////////////////////////////////////////////////////////////////////
 
 
 
 
 

 
 
 
 
 
 
   
 
 
 
 
 
 
 
 

 
 