
            
          <div id="div-main" class="col-md-10 animated">
              <!-- dashboard datas -->
                 
                 <div class="row">
                 
                    <div class="col-md-12">
                         <div class="panel panel-primary">
                          <div class="panel-heading">
                            <h3 class="panel-title">Students</h3>
                          </div>
                          <div class="panel-body">
                         
                
                          
                            <table class="table table-striped table-bordered">
                               <tr>
                                   <th>Student Name</th>
                                   <th>Reg No</th>
                                   <th>Department</th>
                                   <th>Faculty</th>
                                   <th>CGPA</th>
                                   <th>Button</th>
                               </tr>
                               <?php foreach($student_details as $details):?>
                               <tr>
                                 <td on><?php echo $details['student_name'];?></td>
                                 <td><?php echo $details['reg_num'];?></td>
                                 <td><?php echo $details['dept'];?></td>
                                 <td><?php echo $details['faculty'];?></td>
                                 <td><?php echo to_2d_place($details['cgpa']);?></td>
                                 <td><a href="<?php echo base_url();?>lecturer/dashboard/add_transcipt/<?php echo $details['student_id'];?>" class="btn btn-success">Add Transcript</a></td>
                               </tr>
                               <?php endforeach;?>  
                             </table> 
                          </div>
                     
                     
                          </div>
                        </div>
                         
                 
                 </div>
                 
                 
              
              <!-- dashboard -->
          </div>    
        </div>
      </div>
      
    <!--/ end lecturers dashboard -->   
      
   
   