  
            
          <div id="div-main" class="col-md-10 animated">
              <!-- dashboard datas -->
                <div class="row">
                   <div class="col-md-12">
                      <div class="panel panel-default">
                      <div class="panel-body">
                        <!-- school intro-->
                         <div class="skool-info text-center">
                           <img src="<?php echo base_url();?>assets/img/tran.jpg" class="pull-left" style="border:1px solid #000;">
                           <h4>USMAN DANFODIO UNIVERSITY<h4>
                           <h5>Katsina State, Nigeria</h5>
                           <h4>STUDENT REPORT FORM</h4> 
                         </div>
                        <!-- school intro -->
                        
                        <!-- student info -->
                        
                          
                            <div class="student-info">
                              <p>NAME : <?php echo strtoupper($student_details->student_name); ?></p>
                              <p>REGISTRATION NUMBER : <?php echo strtoupper($student_details->reg_num);?></p>
                              <P>FACULTY : <?php echo strtoupper($student_details->faculty);?></P>
                              <P>DEPARTMENT : <?php echo strtoupper($student_details->dept);?></P>
                            
                               <input id="student_id" type="hidden" value="<?php echo $student_details->student_id;?>" />
                              <br><br>
                              </div>
                            
                        <!-- student info -->
                          
                              <!-- select year input -->
                             <div class="input-data"> 
                              <div class="row">
                                <div class="col-md-4">
                                  <select class="form-control" id="study_year">
                                  <option>Select Level</option>
                                   <?php foreach($levels as $lev):?>
                                       <option value="<?php echo $lev['level_id'];?>"><?php echo $lev['level_title'];?></option>
                                
                                    <?php endforeach;?>
                                  </select>
                                </div>
                                <div class="col-md-4">
                                  <p>PREVIOUS CGPA : <?php echo $student_details->cgpa?></p>
                                </div>
                                <div class="col-md-4">
                                  
                                  <div id="list_of_code"></div>
                                </div>
                              </div> 
                              </div>
                              <!-- select year input -->
                              
                            
                        
                        
                      </div>
                    </div>
                   </div>
                   
                   <div  id="result_table" class="col-md-12 display-result-table">
                     <div class="panel panel-default">
                      <div class="panel-body">
                        
                        <div id="first_semester_table"><!-- start of first semester table -->
                        <!-- table for first semester records -->
                             <h4>First Semester</h4><button  id="add_btn_first" class="btn btn-info pull-right btn-up">Add New Row</button>
                             <div id="feedback_first_semester"></div>
                             <input id="semester_id" type="hidden" value="1"  />
                             <table class="table table-bordered" id="new_row_first">
                                <tr>
                                <th>S/No</th>
                                <th>Code</th>
                                <th>Course Title</th>
                                <th>Credits</th>
                                <th>Grade</th>
                                <th>GP</th>
                                <th>PE</th>
                                <th>Delete</th>
                                </tr>
                                   
                             
                             </table> 
                             <div class="row">
                              <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Credit Load</th>
                                 <th id="total_credit_first"></th>
                               </tr>
                             </table>
                              </div>
                                <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Point Earn</th>
                                 <th id="total_point_first"></th>
                               </tr>
                             </table>
                              </div>
                              
                               <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>GPA</th>
                                 <th id="gpa_first"></th>
                               </tr>
                             </table>
                              </div>
                              <div id="feedback" class="col-md-12">
                                    
                              </div>
                              
                            </div><!-- end of first semester table -->  
                            
                              <div class="col-md-4">
                                  <button class="btn btn-success" id="save_first" ><i class="fa fa-check"></i> Save 1st Semester </button>
                                  </div>
                             </div>
                             
                             
                        <!-- table for first first records -->
                        <hr>
                        
                        <div id="second_semester_table"><!-- start of first semester table -->
                         <!-- table for second semester records  -->
                             <h4>Second Semester</h4><button id="add_btn_second"  class="btn btn-info pull-right btn-up">Add New Row</button>
                             <input id="semester_id_second" type="hidden" value="2"  />
                             <table class="table table-bordered" id="new_row_second">
                                <tr>
                                <th>S/No</th>
                                <th>Code</th>
                                <th>Course Title</th>
                                <th>Credits</th>
                                <th>Grade</th>
                                <th>GP</th>
                                <th>PE</th>
                                <th>Delete</th>
                                </tr>
                               
                             </table>
                             
                             
                             <div class="row">
                              <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Credit Load</th>
                                 <th id="total_credit_second"></th>
                               </tr>
                             </table>
                              </div>
                                <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Point Earn</th>
                                 <th id="total_point_second"></th>
                               </tr>
                             </table>
                              </div>
                              
                               <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>GPA</th>
                                 <th id="gpa_second"></th>
                               </tr>
                             </table>
                              </div>
                              <div class="col-md-3">
                                     <table class="table table-striped">
                                       <tr>
                                         <th>CGPA</th>
                                         <th>4.89</th>
                                       </tr>
                                     </table>
                                  </div>
                                   </div><!-- end of second semester table -->
                                 <div class="col-md-4">
                                  <button class="btn btn-success" id="save_second"><i class="fa fa-check"></i> Save 2nd Semester </button>
                                  </div>  
                              
                              </div>
                              
                        <!-- <table for first semester records -->
                           
                        
                         
                           
                      </div>
                    </div>
                   </div>
                </div>
              <!-- dashboard -->
          </div>    
        </div>
      </div>
      
    <!--/ end lecturers dashboard -->   
      
   
   