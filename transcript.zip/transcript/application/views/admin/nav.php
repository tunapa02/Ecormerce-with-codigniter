    <!-- lecturers dashboard -->
     
      <div class="container-fluid">
        <div class="row">
          <div id="div-nav" class="col-md-2 animated">
              
              
            <div class="panel panel-primary">
              <div class="panel-heading btn-search">
                <h3 class="panel-title"><i class="fa fa-gear"></i> Menu</h3>
                
              </div>
              <div class="panel-body">
                <div class="list-group">
                  <a href="<?php echo base_url();?>admin/dashboard" class="list-group-item"><i class="fa fa-dashboard"></i>  Home</a>    
                  <a href="#" class="list-group-item" data-toggle="modal" data-target="#modal_add_lecturer"><i class="fa fa-plus"></i> Add Lecturer</a>
                  <a href="<?php echo base_url();?>admin/dashboard/add_course" class="list-group-item"><i class="fa fa-tasks"></i> Add_course</a>    
                  
                </div>
              </div>
            </div>  
          </div>
          
          
          
          
          
          
          
         <!-- modal for adding Drugs -->
                   
                   <div class="modal fade" id="modal_add_lecturer" role="dialog" aria-labelledby="gridSystemModalLabel">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title text-center" id="gridSystemModalLabel"><i class="fa fa-plus"></i> Add Lecturer</h4>
                          </div>
                          <div class="modal-body">
                            <div class="container-fluid">
                            <div id="feedback_add_lecturer"></div>
                             <div class="row">
                               <form action="<?php echo base_url();?>admin/dashboard/add_lecturer" method="post" id="form_add_lecturer">

                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label for="exampleInputEmail1">Lecturer Name</label>
                                        <input type="text" class="form-control" id="lecturer_name" name="lecturer_name" placeholder="Lecturer Name">
                                    </div>  
                                 </div>
                             </div>
                             <div class="row">
                                <div class="col-md-6">
                                   <div class="form-group">
                                        <label for="exampleInputEmail1">Level Cordinator Of</label>
                                        <select name="level" id="level" class="form-control">
                                           <option>Select level</option>
                                           <option value="1">Level 100</option>
                                           <option value="2">Level 200</option>
                                           <option value="3">Level 300</option>
                                           <option value="4">Level 400</option>
                                        </select>
                                    </div>    
                                </div>
                                <div class="col-md-6">
                                   <div class="form-group">
                                        <label for="exampleInputEmail1">Department</label>
                                        <input type="text" class="form-control" id="dept" name="dept" placeholder="Department">
                                    </div>    
                                </div>
                             </div>
                            
                             <div class="row">
                                <div class="col-md-6">     
                                    <div class="form-group">
                                       <label for="exampleInputEmail1">Username</label>
                                        <input type="text" class="form-control" id="uname" name="uname" placeholder="Username">
                                    </div>
                                </div>
                                <div class="col-md-6">     
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">password</label>
                                        <input type="text" class="form-control" id="password" name="password" placeholder="Password">
                                    </div>
                                </div>         
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-plus"></i> Add Lecturer</button>  

                          </div>
                          </form>
                        </div>
                      </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                    
             
            
           