<?php $this->load->view('includes/header_lect');?>



<?php $this->load->view('lecturer/nav'); ?>


<?php $this->load->view($main); ?>



<?php $this->load->view('includes/footer');?>