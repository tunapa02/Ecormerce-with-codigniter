  
    <!-- Main Section -->
     <section id="section-intro">     
        <div class="container">
          <div class="row">
          <div class="col-md-3"></div>
             <div class="col-md-6">
             <h2 class="text-white intro-text text-center">TRANSCRIPT SYSTEM</h2>
             
             
               <div class="well">
                <h4 class="text-center">Login into Dashboard</h4>
               
             <div id="feedback"></div>
           <form id="form_login" action="<?php echo base_url();?>auth/login" method="post">
              <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <input type="text" class="form-control" placeholder="Email OR Username" name="email" id="email">
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Select Account</label>
                    <select name="account_type" id="account_type" class="form-control">
                       <option>Select Account</option>
                       <option value="1">Admin</option>
                       <option value="0">Lecturer</option>
                    </select>
              </div>
              
               <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" class="form-control" placeholder="Password" name="password" id="password">
              </div>   
             
              <button type="submit" class="btn btn-info btn-block">Login</button>
            </form>
             
               
               </div>
             
             </div><!-- end of main -->
             
             
             <div class="col-md-3"></div>
             
             
             
            
              
            
          </div>
        </div>
      </section>     
       
    <!--/ Main section -->    
      
      
      
      
     
     <!-- modal for Drugs -->
                   
                   <div class="modal fade" id="modal_login" role="dialog" aria-labelledby="gridSystemModalLabel">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title text-center" id="gridSystemModalLabel">Login</h4>
                          </div>
                          <div class="modal-body">
                            <div class="container-fluid">
                            <div id="feedback"></div>
                             <div class="row">
                             <form id="form_login" action="<?php echo base_url();?>auth/login" method="post">
                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label for="exampleInputEmail1">Email OR Username</label>
                                        <input type="text" class="form-control" placeholder="Email OR Username" name="email" id="email">
                                    </div>  
                                 </div>
                             </div>
                             <div class="row">
                                <div class="col-md-12">
                                   <div class="form-group">
                                         <label for="exampleInputEmail1">Select Account Type</label>
                                        <select name="account_type" id="account_type" class="form-control">
                                           <option>Select Account Type</option>
                                           <option value="1">Admin</option>
                                           <option value="0">Lecturer</option>
                                        </select>
                                    </div>    
                                 </div>
                             </div>
                               <div class="row">
                                <div class="col-md-12">
                                   <div class="form-group">
                                        <label for="exampleInputEmail1">Password</label>
                                        <input type="password" class="form-control" placeholder="Password" name="password" id="password">
                                    </div>    
                                 </div>
                             </div>
                           
                          </div>
                          <div class="modal-footer">
                            <button id="login_submit" type="submit" class="btn btn-success btn-block">Sign in</button>
                          </div>
                          </form>
                        </div><!-- /.modal-content -->
                      </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                   
                  <!--/ modal for drugs -->