<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model { 


  //this method checks for a valid username and password
  public function login($email, $password, $account_type)
  {    
        //$email = $this->input->post('email');
	    //$password = sha1($this->input->post('password'));
		//$account_type = (int)$this->input->post('account_type');
		$clean_account = (int)$account_type;
       
	   
	 
	   $this->db->select('lecturers.*');
	   $this->db->where('uname', $email);
	   $this->db->where('password', $password);
	   $this->db->where('user_level',$account_type);
	  
	   $this->db->limit(1);
	   
	   $q = $this->db->get('lecturers');
	   if($q->num_rows()>0){
		   
		       $row = $q->row();
			   
			   $user_data = array(
			   
			        'lecturer_id' => (int)$row->lecturer_id,
					'lecturer_name'   => $row->lecturer_name,
					'level_id'  => $row->level_id,
					'dept'  =>     $row->dept,
					'uname' => $row->uname,
					'password' => $row->password,
					'user_level' => (int)$row->user_level,
					'loggedin'  => true
					
			   
			   );
			   
			   
			   $this->session->set_userdata($user_data);
		        return true;
		   
		   }else{
			      
				  return false;
			   
			   }
   
  
  }
  
  




  /* public function admin_auth($email, $password, $clean_account)
   {
      
	   $this->db->select('admin.*');
	   $this->db->where('admin_email', $email);
	   $this->db->where('password', $password);
	
	   $this->db->limit(1);
	   
	   $q = $this->db->get('admin');
	   if($q->num_rows()>0){
		   
		       $row = $q->row();
			   
			   $user_data = array(
			   
			        'admin_id' => (int)$row->admin_id,
					'admin_name'   => $row->admin_name,
					'admin_email'  => $row->admin_email,
					'phone'  =>     $row->phone,
					'user_level' => (int)$row->user_level,
					'loggedin'  => true
					
			   
			   );
			   
			   
			   $this->session->set_userdata($user_data);
		        
		       return true;
		   }else{
			      
				  return false;
			   
			   }
   
   }


    //this authenticate the lecturer
    public function lecturer_auth($email, $password, $clean_account)
   {
      
	   $this->db->select('lecturers.*');
	   $this->db->where('uname', $email);
	   $this->db->where('password', $password);
	  
	   $this->db->limit(1);
	   
	   $q = $this->db->get('lecturers');
	   if($q->num_rows()>0){
		   
		       $row = $q->row();
			   
			   $user_data = array(
			   
			        'lecturer_id' => (int)$row->lecturer_id,
					'lecturer_name'   => $row->lecturer_name,
					'level_id'  => $row->level_id,
					'dept'  =>     $row->dept,
					'uname' => (int)$row->uname,
					'password' => $row->password,
					'user_level' => (int)$row->user_level,
					'loggedin'  => true
					
			   
			   );
			   
			   
			   $this->session->set_userdata($user_data);
		        return true;
		   
		   }else{
			      
				  return false;
			   
			   }
   
   }

*/

     /**
	 * this methods distroys the users session data
	 
	public function logout()
	{
	    $data = array( 'admin_id','admin_name' , 'admin_email', 'phone', 'user_level', 'loggedin' );
		$logout = $this->session->unset_userdata($data);
		return $logout;
	}
	
	*/
	
	public function logout()
	{
	  
	 $data = array( 'lecturer_id','lecturer_name' , 'level_id', 'dept', 'uname', 'password','user_level', 'loggedin');
		$logout = $this->session->unset_userdata($data);
		return $logout;
	
	}
	
	
	
	 /* 
	   *$this method confirms if a users is logged_in
	   *
	   */
		public function loggedin()
		{
			
		  return (bool)$this->session->userdata('loggedin');
		  
		}	













}//end class