<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

   public function __construct()
   {
	   parent::__construct();  
	   
	    $ses_id = (int)$this->session->userdata('lecturer_id');
			  if(empty($ses_id)){
				 redirect('home');	  
		        }
				
				
		$account_type = (int)$this->session->userdata('user_level');
			  if($account_type !== 0){
				 redirect('home');	  
		        }		
						
	   
   }
   
   
   
   //this method display home page
   public function index()
   
   
   {
	   
	   
	  $user_data = $this->session->all_userdata();
	  //dump($user_data);
	 // dump($this->session->all_userdata()); 
     $data['title'] = 'Lecturer Dashboard';
	 $data['main'] = 'lecturer/dashboard';
	 
	 $data['student_count'] = $this->Trans_model->get_student_count();
	 $data['transcript_count'] = $this->Trans_model->get_transcript_count();
	 $data['courses_count'] = $this->Trans_model->get_courses_count();
	 
	 $data['student_details'] = $this->Trans_model->get_all_student();
	 $this->load->view('templates/template_lect', $data);
   
   }
   
   
 
   
   //this method adds student to the database
   public function add_student()
   {
	
       if(isset($_POST['student_name']) && isset($_POST['reg_num']) && isset($_POST['dept']) && isset($_POST['faculty']) && isset($_POST['date_admit']))
	   {
		   
		   $query = $this->Trans_model->add_student();
		   if($query){
			      
			     echo 'inserted';
			   }else{
				   
				      echo 'error';
				   }
		
		
		}
   
   }



	 //this method displays the transcript page
	 public function transcript()
	 {
		 
		 $data['title'] = 'Students Transcritp'; 
		 $data['main']  = 'lecturer/edit_transcript';
		 $data['student_details'] = $this->Trans_model->get_all_student();
		 //dump($data['student_details']);
		 $this->load->view('templates/template_lect', $data);
		 
	 }
	 
	 
	 //this method adds a transcript
	 public function add_transcipt()
	 {
	 	  $student_id = (int)$this->uri->segment(4); 
		  //dump($student_id);
		  
		 $data['title'] = 'Add Transcritp'; 
		 $data['main']  = 'lecturer/add_transcript';
		 $data['student_details'] = $this->Trans_model->get_student_info($student_id);
		 //dump($data['student_details']);
		 
		 //getting the free available year for transcript
		 $data['levels'] = $this->Trans_model->get_levels($student_id);
		 
		 //dump($data['levels']);
		 $this->load->view('templates/template_lect', $data);
	    
	 
	 }
	 
	 
	 



 //this method gets all ccourses from database
 public function get_course_info()
 {
	 
    if(isset($_GET['course_code'])){
		  
		    $course_code = $_GET['course_code'];
		  
		  $course_info = $this->Trans_model->get_course_info($course_code);
		  if($course_info){
			  
			     foreach($course_info as $course){
					    
						   echo json_encode($course);
						   // echo '<div>'.$course['course_code'].'</div>';
					     
					     }
			  
			  }else{
				     
					 echo 'error...';
				  
				  }
		
		}
  
 }


  
  
  //this method creates a drop_down menu
  public function dropdown()
  {
	   
     if(isset($_POST['semester'])){
		 
		 $semester = $_POST['semester'];
		     $option = '';
	 
	 $course_info = $this->Trans_model->get_course_dropdown_info($semester);
	  if($course_info){
		  
		    foreach($course_info as $course){
		    
			
			$option .= '<option value="'.$course['course_id'].'">'.$course['course_code'].'</option>';
		      
		    
			   }
			
			 echo $option;
			
		  
	   }else{
				   
				  echo 'error';
				}
	  
		 
	   }
  
  } 
  
  
  
  
  //this method gets course title
  public function get_course_title()
  {
	  
     if(isset($_POST['course_id'])){
		     
			$course_id = $_POST['course_id'];
		    $course_info = $this->Trans_model->get_course_info_by_id($course_id);
			if($course_info){
				
				   foreach($course_info as $course){
					   
					       echo json_encode($course);
					   
					   }
				
				}else{
					
					  echo 'error';
					
					}
		 
		 }
  
  }
  
  
  
  
  //this method saves first semester transript
  public function save_transcript_first()
  {  
     
	  if(isset($_POST['student_id']) && isset($_POST['level_id']) && isset($_POST['course_id']) && isset($_POST['grade_point']) && isset($_POST['point_earn']) && isset($_POST['semester_id'])){
		    
			
			
			
		 
			 //making the query to save the transcript
			 $query = $this->Trans_model->insert_first_trans();
			 if($query){
				   
				   echo "inserted";
				 
				 }else{
					 
					   echo "error";
					 }
	
		  }
  
  }
  
  
  //this function updates the student gpa , grade_point, crdeit_load
  public function insert_total_point()
  {
	    if(isset($_POST['semester_id']) && isset($_POST['level_id']) && isset($_POST['student_id']) && isset($_POST['credit']) && isset($_POST['point']) && isset($_POST['student_gpa'])){
	        
			
             
			 //making the query
		     $query = $this->Trans_model->insert_total_gpa();
			 if($query){
				   
				   echo 'inserted';
				 
				 }else{
					 
					   echo 'error';
					 }
			 
  
		}
  }
  
  
  
  
  
  
  
  //this method updates student info 
  public function update_student_info()
  {
	  if(isset($_POST['student_id']) && isset($_POST['credit']) && isset($_POST['point'])){
	      
		     $student_id     = $_POST['student_id'];
			 $new_credit     = $_POST['credit'];
			 $new_point      = $_POST['point'] ;
		  
		  //get the current values of student info
		  $student_current_info = $this->Trans_model->get_current_info($student_id);
		  if($student_current_info){
		    foreach($student_current_info as $info){
			  
			  $current_credit = (int)$info['total_credit_load'];
			  $current_point  = (int)$info['total_point_earn']; 
			  
			  $updated_credit = (int)$new_credit + (int)$current_credit;
			  $updated_point  = (int)$new_point  + (int)$current_point;
			  $updated_cgpa   = $updated_point / $updated_credit;
			  
			  
			  //making the query update
			  $new_student_info = $this->Trans_model->update_student_info($updated_credit,$updated_point, $updated_cgpa, $student_id );  
			  if($new_student_info){
				     
					 echo 'Student inserted';
				  
				  }else{
					    
						echo 'error_student_info';
					  
					  }
			  
			  
			    
			    
		    }	
		  
		  }
      }
  
  }
  
  
/*/////////////////////////////////////////////////////////////////////////

The blocks of code below works on the display, printing and downloading of
the student transcript

/////////////////////////////////////////////////////////////////////////*/
  
  
  //this method displays all students transcripts
  public function view_transcript()
  {
  
	 $data['title'] = 'Students Transcritp'; 
	 $data['main']  = 'lecturer/view_transcript';
	 $data['student_details'] = $this->Trans_model->get_all_student();
	 //dump($data['student_details']);
	 $this->load->view('templates/template_lect', $data);
  
  }
  


  //this method display the students transcript
  public function prev_transcipt()
  {
      
	  $student_id = (int)$this->uri->segment(4);
	  $level_id   = (int)$this->uri->segment(5);
	  $semester_first  = 1;
	  $semester_second = 2; 
	  //dump("student_id ".$student_id);
	  //dump("level_id ".$level_id);
	  
	  $data['main']  = 'lecturer/prev_transcript';
	  $data['student_details'] = $this->Trans_model->get_student_info($student_id);
	  //dump($data['student_details']);
	  $data['student_transcript_first'] = $this->Trans_model->get_student_course_info($student_id, $level_id, $semester_first);
	  
	  $data['student_transcript_second'] = $this->Trans_model->get_student_course_info($student_id, $level_id, $semester_second);
	  
	  //dump($data['student_transcript']);
	  $data['student_total_first'] = $this->Trans_model->get_student_credit_load($student_id, $level_id, $semester_first);
	  
	   $data['student_total_second'] = $this->Trans_model->get_student_credit_load($student_id, $level_id, $semester_second);
	  //dump($data['student_totals']);
	  
	  $this->load->view('templates/template_lect', $data);
  
  
  }
  
  
  
  //this method generates the transcript pdf for printing
  public function get_pdf()
  { 
      $data['title'] = 'Students Transcritp'; 
	//getting the uri segment
      $student_id = (int)$this->uri->segment(4);
	  $level_id   = (int)$this->uri->segment(5);
	  $semester_first  = 1;
	  $semester_second = 2; 
	
	  $data['main']  = 'lecturer/prev_transcript';
	  $student_details = $this->Trans_model->get_student_info($student_id);
	  //dump($data['student_details']);
	  $student_transcript_first = $this->Trans_model->get_student_course_info($student_id, $level_id, $semester_first);
	  
	  $student_transcript_second = $this->Trans_model->get_student_course_info($student_id, $level_id, $semester_second);
	  
	  //dump($data['student_transcript']);
	  $student_total_first = $this->Trans_model->get_student_credit_load($student_id, $level_id, $semester_first);
	  
	   $student_total_second = $this->Trans_model->get_student_credit_load($student_id, $level_id, $semester_second);
  
  
  
  
  
  
  
  
    //loading the pdf library
	$this->load->library('fpdf/fpdf');  
    
	$pdf = new FPDF('p', 'mm', 'A4');

    $pdf->AddPage();
	
	
	//cell(width, height, text, border, endline, [align]);
	//$pdf->Image('img/bukk.png', 10, 6, 20,20);
	
	//set up for the transcript
	
	//student info area 
	
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 12);
	
	$pdf->Image(base_url().'assets/img/tran.jpg', 10, 6,20, 20);
	$pdf->cell('55', 5, '',0, 0);
	$pdf->cell('79', 5, 'USMAN DANFODIO UNIVERSITY',0, 0, 'C');
	$pdf->cell('55', 5, '',0, 1);
	
	//next line for state and country
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 9);
	
	$pdf->cell('55', 5, '',0, 0);
	$pdf->cell('79', 5, 'Katsina State, Nigeria',0, 0, 'C');
	$pdf->cell('55', 5, '',0, 1);
	
	
	//next line for student end of session form
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 12);
	
    $pdf->cell('55', 5, '',0, 0);
	$pdf->cell('79', 5, 'STUDENT REPORT FORM',0, 0, 'C');
	$pdf->cell('55', 5, '',0, 1);
	
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 5, '',0, 1);
	
	
	//next line for student DETAILS
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 10);
	
    $pdf->cell('31', 5, 'NAME:',0, 0,'R');
	//set font to Arial NO bold 14pt
    $pdf->SetFont('Arial', '', 10);
	$pdf->cell('55', 5, strtoupper($student_details->student_name) ,0, 1);
	
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 10);
	$pdf->cell('31', 5, 'REGISTRATION NO:',0, 0, 'R');
	//set font to Arial NO bold 14pt
    $pdf->SetFont('Arial', '', 10);
	$pdf->cell('55', 5,  strtoupper($student_details->reg_num),0, 1);
	
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 10);
	$pdf->cell('31', 5, 'FACULTY:',0, 0,'R');
	//set font to Arial NO bold 14pt
    $pdf->SetFont('Arial', '', 10);
	$pdf->cell('55', 5, strtoupper($student_details->faculty),0, 1);
	
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 10);
	$pdf->cell('31', 5, 'DEPARTMENT:',0, 0,'R');
	//set font to Arial NO bold 14pt
    $pdf->SetFont('Arial', '', 10);
	$pdf->cell('55', 5, strtoupper($student_details->dept),0, 1);
	
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 10);
	$pdf->cell('31', 5, 'PROGRAMME:',0, 0, 'R');
	//set font to Arial NO bold 14pt
    $pdf->SetFont('Arial', '', 10);
	$pdf->cell('55', 5, strtoupper($student_details->dept),0, 1);
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 5, '',0, 1);
	
	$pdf->SetFont('Arial', 'B', 8);
	
    $pdf->cell('63', 5, 'LEVEL '.convert_to_hundred($level_id),0, 0);
	$pdf->cell('63', 5, 'PREVIOUS CGPA : '.$student_details->cgpa,0, 0, 'C');
	$pdf->cell('63', 5, 'CURRENT CGPA : '.$student_details->cgpa,0, 1, 'R');
	
	
	//end of student info area 
	
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 5, '',0, 1);
	
	
	//start student courses area
	
	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 12);
	
	//first semester
	$pdf->cell('55', 5, '',0, 0);
	$pdf->cell('79', 5, 'FIRST SEMESTER RESULT',0, 0, 'C');
	$pdf->cell('55', 5, '',0, 1);
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 3, '',0, 1);
	
	//FONT SIZE
	$pdf->SetFont('Arial', 'B', 9);
	
	//STUDENT COURSE CODES
	$pdf->cell('31', 8, 'Code',1, 0);
	$pdf->cell('60', 8, 'Course Title',1, 0);
	$pdf->cell('23', 8, 'Credits',1, 0);
	$pdf->cell('23', 8, 'Grade',1, 0);
	$pdf->cell('23', 8, 'GP',1, 0);
	$pdf->cell('23', 8, 'PE',1, 1);
	
	foreach($student_transcript_first as $trans_first){
	$pdf->cell('31', 8, $trans_first['course_code'],1, 0);
	$pdf->cell('60', 8, $trans_first['course_title'],1, 0);
	$pdf->cell('23', 8, $trans_first['credits'],1, 0);
	$pdf->cell('23', 8, convert_to_alpha((int)$trans_first['grade_point']),1, 0);
	$pdf->cell('23', 8, $trans_first['grade_point'],1, 0);
	$pdf->cell('23', 8, $trans_first['point_earned'],1, 1); 
	}
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 3, '',0, 1);
	
	$pdf->cell('51', 5, 'Total Credit Load : '. $student_total_first->total_credit_load,0, 0);
	$pdf->cell('51', 5, 'Total Point Earn : '.$student_total_first->total_point_earn,0, 0);
	$pdf->cell('51', 5, 'GPA : '.to_2d_place($student_total_first->gpa),0, 1);
	//first semester
	
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 5, '',0, 1);
	
	//second semester
	 	//set font to Arial bold 14pt
    $pdf->SetFont('Arial', 'B', 12);
	
	$pdf->cell('55', 5, '',0, 0);
	$pdf->cell('79', 5, 'SECOND SEMESTER SEMESTER RESULT',0, 0, 'C');
	$pdf->cell('55', 5, '',0, 1);
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 3, '',0, 1);
	
	//FONT SIZE
	$pdf->SetFont('Arial', 'B', 9);
	
	//STUDENT COURSE CODES
	$pdf->cell('31', 8, 'Code',1, 0);
	$pdf->cell('60', 8, 'Course Title',1, 0);
	$pdf->cell('23', 8, 'Credits',1, 0);
	$pdf->cell('23', 8, 'Grade',1, 0);
	$pdf->cell('23', 8, 'GP',1, 0);
	$pdf->cell('23', 8, 'PE',1, 1);
	
	
	foreach($student_transcript_second as $trans_second){
	$pdf->cell('31', 8, $trans_second['course_code'],1, 0);
	$pdf->cell('60', 8, $trans_second['course_title'],1, 0);
	$pdf->cell('23', 8, $trans_second['credits'],1, 0);
	$pdf->cell('23', 8, convert_to_alpha((int)$trans_second['grade_point']),1, 0);
	$pdf->cell('23', 8, $trans_second['grade_point'],1, 0);
	$pdf->cell('23', 8, $trans_second['point_earned'],1, 1); 
	}
	
	//A DUMMING LINE FOR INDENTATION
	$pdf->cell('189', 3, '',0, 1);
	
	$pdf->cell('45', 5, 'Total Credit Load : '.$student_total_second->total_credit_load,0, 0);
	$pdf->cell('45', 5, 'Total Point Earn : '.$student_total_second->total_point_earn,0, 0);
	$pdf->cell('45', 5, 'GPA : '.to_2d_place($student_total_second->gpa),0, 0);
	$pdf->cell('45', 5, 'CGPA : '.to_2d_place($student_details->cgpa),0, 1);
	
	
	
	
	//second semester
	//end student courses  area
	
	
	
	
	
	//set up for transcript ends here
	
	
	//outputing the complete pdf
	$pdf->Output('',strtoupper($student_details->reg_num).'.pdf','');

  
  }
  
  
  
  


  
  


}//end of class