<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

   
   public function __construct()
   {
      parent::__construct();
	  
	     $ses_id = (int)$this->session->userdata('lecturer_id');
			  if(empty($ses_id)){
				 redirect('home');	  
		        }
				
				
		$account_type = (int)$this->session->userdata('user_level');
			  if($account_type !== 1){
				 redirect('home');	  
		        }		
		
   }
   
   
   
   //this displays the admin dashboard
   public function index()
   {
     
	  $user_data = $this->session->all_userdata();
	  //dump($user_data);
	  
      $data['title'] = 'Admin dashboard';
	  $data['main']  = 'admin/dashboard';
	  $data['lecturers'] = $this->Trans_model->get_lecturers();
	  $this->load->view('templates/template_admin', $data);
   
   }
   
   
   
   	 
	 //this is a test method for adding courses
	 public function add_course()
	 {  
	 
	    if(isset($_POST['course_title']) && isset($_POST['course_code']) && isset($_POST['credits']) && isset($_POST['level']) && isset($_POST['semester'])){
			
			 
			$query = $this->Trans_model->add_course();
			//dump($query);
			if($query){
				   
				echo 'inserted';
				}else{
					   
					   echo 'error';
					
					}
				
				  
			
			}else{
				   $data['title'] = 'Admin Dashboard';
	               $data['main'] = 'admin/add_course';
	               $this->load->view('templates/template_admin', $data);
				   //$this->load->view('lecturer/add_course');
				
				}
	    
	 }




   //this method adds lecturer by the administrator
   public function add_lecturer()
   {
        if(isset($_POST['lecturer_name']) && isset($_POST['level']) && isset($_POST['dept']) && isset($_POST['uname']) && isset($_POST['password']))
	   {
		   
		   $query = $this->Trans_model->add_lecturer();
		   if($query){
			      
			     echo 'inserted';
			   }else{
				   
				      echo 'error';
				   }
		
		
		}
   
   }



  
   
   




}//end of class