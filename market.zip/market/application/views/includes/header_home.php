<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>UDU Commerce</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
      
    <!-- Custom template -->  
    <link href="<?php echo base_url();?>assets/css/navbar.css" rel="stylesheet">  
      
    <!-- font-awesome -->
      <link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">
      
    <!-- Custom template -->  
    <link href="<?php echo base_url();?>assets/css/app.css" rel="stylesheet">

 
  </head>

  <body>
    
      
        
      
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar">
                    <span class="button-label">Menu</span>
                    <div class="button-bars">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </div>
            </button>
            <a class="navbar-brand" href="<?php echo base_url(); ?>"><img class="udu-logo-home" src="<?php echo  base_url();?>assets/img/logo.png" /></a> 
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
           <!-- <li><a href="#"><i class="fa fa-home"></i> Buk Market</a></li> -->
            </ul>      
           
          <ul class="nav navbar-nav navbar-right">
            <li><a href="<?php base_url()?>admin/dashboard/product">Admin</a></li>
             <li><a href="<?php base_url()?>auth/register">Register</a></li>
             <?php if($this->session->userdata('user_id')){
            
			      echo '<li><a href="'.base_url().'user">My Account</a></li>';
			      echo '<li><a href="'.base_url().'auth/logout">Logout</a></li>'; 
				
             
             }else{
				 
				   echo '<li><a href="'.base_url().'auth" >Login</a></li>';
				 
				  }
			 
			 
			 
			 
			 ?>
              <li><a href="<?php echo base_url();?>post" class="btn btn-login"><i class="fa fa-plus"></i> Post Product</a></li>
          </ul>    
        </div><!--/.nav-collapse -->
      </div>
    </nav>
      
      