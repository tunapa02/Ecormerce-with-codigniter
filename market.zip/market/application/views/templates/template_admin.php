<?php $this->load->view('includes/header_admin');?>

<?php $this->load->view('public/nav'); ?>

<?php $this->load->view($main);?>



<?php $this->load->view('includes/footer');?>