<?php $this->load->view('includes/header_auth');?>



<?php $this->load->view($main);?>



<?php $this->load->view('includes/footer');?>