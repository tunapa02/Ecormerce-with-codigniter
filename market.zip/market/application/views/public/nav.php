<div class="container-fluid">
      <div class="row">
        


<div class="col-md-2">
         
        
        
  
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-gear"></i> Menu</h3>
          </div>
          <div class="panel-body">
             <div class="list-group">
          <!-- 
           <a class="list-group-item" href="<?php echo  base_url();?>admin/dashboard"><i class="fa fa-gear"></i> Dasboard</a>
             
             -->
             <a class="list-group-item" href="<?php echo  base_url();?>admin/dashboard/users"><i class="fa fa-user"></i> Users</a>
            
            <a class="list-group-item" href="<?php echo  base_url();?>admin/dashboard/product"><i class="fa fa-gear"></i> Items</a>
            
            <a class="list-group-item" href="#" data-toggle="modal" data-target="#modal_add_category"><i class="fa fa-plus" ></i> Add Category</a>
           
          </div>
        
          </div>
        </div>
        
        
        </div>
        
        
        
    
        
        
        
        
        
        
        
        
        
                     
              <!-- modal -for drug costing -->
                       <!-- Modal -->
            <div class="modal fade" id="modal_add_category" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    
                  </div>
                  <div class="modal-body">
                  
                  <div class="panel panel-primary">
                      <div class="panel-heading">
                        <h3 class="panel-title">Add Category</h3>
                      </div>
                      <div class="panel-body">
                        
                               <div class="container-fluid">
                       <div id="feedback_add_category"></div>
                        <div class="row">
                        <form action="<?php echo base_url(); ?>admin/dashboard/add_category" method="post" id="form_add_category">
                            <div class="col-md-12">
                              <div class="form-group">
                                
                                <input type="text" name="category_name" class="form-control" id="category_name" placeholder="Category Name"> 
                                </div>  
                            </div>
                            <div class="col-md-12">
                               <div class="form-group">
                                 <textarea class="form-control" placeholder="Category Description" name="category_desc" id="category_desc"></textarea>
                               </div>
                            </div>
                       </div> 
                    </div>
                  </div>
                  <div class="modal-footer">
                    
                    <button type="submit" class="btn btn-primary form-control">Add Category</button>
                  </form>
                  </div>
                        
                      </div>
                    </div>
                  
             
                  
                </div>
              </div>
            </div>
                 <!-- modal for costing drugs --> 
      
     