
   <style>
     
	
 

ul {
  list-style-type: none;
  
}
 
h3 {
  font: bold 20px/1.5 Helvetica, Verdana, sans-serif;
}
 
li img {
  float: left;
  margin: 0 15px 0 0;
}
 
li p {
  font: 200 12px/1.5 Georgia, Times New Roman, serif;
}
 
li {
  padding: 5px;
  overflow: auto;
}
 

	 
   </style>
   
   <!-- section -->
      
      <section>
        
          <div class="container">
            <div class="row">
              
              <div class="col-md-8">
                
                  
                 <div class="big_image">
                     <div class="row">
                       <div class="col-md-4">
                         <img class="product_page_img" class="image-responsive" src="<?php echo base_url().'/'. $product_details->image_url ;?>">
                         
                       
                    
                         
                         
                       </div>
                       <div class="col-md-3">
                         <h3><?php echo $product_details->product_title; ?></h3>
                       <h3>₦<?php echo $product_details->product_price; ?></h3>
                       </div>
                     </div>
                </div>    
                
                  <br>
                 <!-- prodduct deatails-->
                    
                    <div class="panel panel-primary">
                      <div class="panel-heading">
                        <h3 class="panel-title">Product Details</h3>
                      </div>
                      <div class="panel-body">
                       
                      <!-- description -->
                         
                          Description : 
                       <div class="well">
                         <p><?php echo $product_details->product_desc; ?></p>
                       </div>
                      
                      <!-- description -->
                      
                      
                         <!-- description -->
                         
                         Sellers Profile : 
                       <div class="well">
                         <p><?php echo $product_details->name;?></p>
                         <p>090773844849</p>
                       </div>
                      
                      <!-- description -->
                        
                        
                      </div>
                    </div>
                 
                 <!-- procuct details -->
                
                  
              </div>
                
                <!-- section -->
              
              <div class="col-md-4">
                
                  
                  <div class="panel panel-primary">
                      <div class="panel-heading">
                        <h3 class="panel-title">Related Product</h3>
                      </div>
                      <div class="panel-body">
                        
                        <div>
                        
                        <?php if($random_product):?>
                        
                      <ul>
                      <?php foreach($random_product as $product):?>  
                        <li>
                          <a href="<?php echo base_url();?>home/product/<?php echo $product['product_id'].'/'.url_title($product['product_title']);?>"><img src="<?php echo base_url().'/'. $product['image_url'];?>" class="related"></a>
                       
                          <h3><?php echo $product['product_title']; ?></h3>
                          <p>₦<?php echo $product['product_price']; ?></p>
                        </li>
                         
                        <?php endforeach; ?>
                       
                        
                      </ul>
                       <?php endif;?>  
                          
                    </div>
                
                        
                      </div>
                    </div>
                
                
                 
              </div>
                
                <!-- section -->
                
                
                
            </div>
          </div>
          
      </section>
      
   <!-- section -->
      
      
      
      
