        <div class="col-md-10">
        
        
           <div class="col-md-4">
             <div class="well text-center round">
                <h3 class="text-primary"><i class="fa fa-user fa-4x"></i></h3>
                <h3 class="text-primary">320</h3>
                <h2 class="text-primary">User</h2>
             </div>
           </div>
           
            <div class="col-md-4">
             <div class="well text-center round">
                <h3 class="text-success"><i class="fa fa-paper-plane fa-4x"></i></h3>
                <h3 class="text-success">172</h3>
                <h2 class="text-success">Items</h2>
             </div>
           </div>
           
           <div class="col-md-4">
             <div class="well text-center round">
                <h3 class="text-danger"><i class="fa fa-outdent fa-4x"></i></h3>
                <h3 class="text-danger">450</h3>
                <h2 class="text-danger">Transactions</h2>
             </div>
           </div>
          
          
          <h3>.</h3>
           
           <hr> 
            
            
            
              
         
           
          
           
          </div> 
       
            
          </div>
        </div>
          
            
        </div>
      </div>
    </div>