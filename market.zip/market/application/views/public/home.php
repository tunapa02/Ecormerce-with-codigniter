 
      <!-- searhc bar -->
      
        <section id="intro_area">
           <div class="container">
              <div class="row">
                 
                  <div class="col-md-2"></div>
                  <!-- sercch bar ---->
                    
                    <div class="col-md-8">
                    <form action="<?php echo base_url();?>home/search" method="post" id="">
                      <div id="search-input">
                         <div class="input-group">
                       
                          <input type="text" required class="form-control input-lg" name="term" id="term"  placeholder="Search for items">
                          <span class="input-group-btn">
                            
                          
                          
                      
                            <button type="submit" class="btn btn-default input-lg"><i class="fa fa-search"></i> Search</button>
                            </span> 
                    </form>
                          
                          
                        </div><!-- /input-group -->  
                      </div>
                        
                    </div>
                  
                   <div class="col-md-2"></div>
                  
                  <!-- searhc bar -->
                  
                  
                  
                  
                  
               </div> 
           </div>
        </section>  
      
      <!-- searhc bar -->
      
      <br>
      
      <!-- listing area -->
      
        <section class="popular-products">
           <div class="container">
             <div class="row">
                 
                 <h3 class="trend">Trending Products</h3>
                 
                <!-- listed products -->
                     
                     
                     <div class="panel panel-default">
                      <div class="panel-body">
                        
                        
                        
                        <?php if($featured_products):?>
                        <?php foreach($featured_products as $product):?>
                         <div class="col-md-3">
                  
                   
                       
                         <a href="<?php echo base_url();?>home/product/<?php echo $product['product_id'].'/'.url_title($product['product_title']);?>"> <img src="<?php echo base_url().'/'.$product['image_url']?>" class="product"></a>
                        
                         <div class="pro_title">
                           <h4><?php echo $product['product_title']; ?></h4>
                           <h4>₦<?php echo $product['product_price']; ?></h4>
                         </div>     
                        
                       <hr>
                   
                 </div>    
                   <?php endforeach;?>
                  <?php endif;?>
              
                 
                 
                 
                     
                     
                     
                

                <!-- listed products -->    
               
                     
                     
                     
                     
             </div> 
           </div>
        </section>
      
      <!-- listing area -->
      
      