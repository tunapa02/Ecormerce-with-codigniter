<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

   
   public function __construct()
   {
      parent::__construct();
	
   }
   
   
   
   //this method display profile page
    //this method displays the login page
   public function index()
   {   
      
	  $user_id = $this->session->userdata('user_id');
      
	  
	  $data['title'] = 'User Dashboard';
	  $data['main']  = 'public/user_dashboard';
	  $data['all_users_product']  = $this->Product_model->get_all_user_prodcuct($user_id);
	  $this->load->view('templates/template_home', $data); 	 
      
   }
   
   
   //this method deletes a product 
   public function delete()
   {
	   
      $pro_id = $this->uri->segment(3);
	  
	  $delete = $this->Product_model->delete_product($pro_id);
	  redirect('user');
	  
   
   } 
   
   
   
   
   
   
   
   
   
   
}//end of class