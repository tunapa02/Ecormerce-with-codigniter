<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

   
   public function __construct()
   {
      parent::__construct();
	
   }
   
   //this method displays All Product
   public function index()
   {
      
	  $data['title'] = 'All Product';
	  $data['main']  = 'public/all_product';
	  $this->load->view('templates/template_home',$data);

   }
   
   
   
   
   
   
   
   
   
   
   
   
}//end of class