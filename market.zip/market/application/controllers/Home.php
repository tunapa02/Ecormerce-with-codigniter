<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

   
   public function __construct()
   {
      parent::__construct();
	
   }
   
   
   //this method displays the index page
   public function index()
   {   
       $user_data = $this->session->all_userdata();
	  //dump($user_data);
       $data['title'] = 'Buk - Market';
	   $data['main']  = 'public/home';
	   $data['featured_products'] = $this->Product_model->get_featured_product();
	   $this->load->view('templates/template_home', $data);  
   }
   
   
   
   //thid method displays a unique product
   public function product()
   {
       $product_id = $this->uri->segment(3);
	   //dump($product_id);
	   
	   $data['product_details'] = $this->Product_model->get_unique_product($product_id);
	   //dump($data['product_details']);
	   $data['random_product'] = $this->Product_model->get_random_product($data['product_details']->category_id,$data['product_details']->product_id );
	   
	   
	   
	   $data['title'] = 'Arewa Mart |'. $data['product_details']->product_title;
	   $data['main']  = 'public/product_page';
	   $this->load->view('templates/template_home', $data);
	   
	     
   }
   
   
   //search method
   public function search(){
	
	      	  
		  
	  if(!empty($_POST['term'])){
		  
		//dump($this->input->post('term'));
		 $term = trim($this->input->post('term'));
		 
		 if($term){
			    
			   $data['search_result'] = $this->Product_model->search($term);
			   $data['count'] = $this->Product_model->search_count($term);
			   
			   //dump($data['search_result']);
			   
			 }else{
				   redirect('home', 'refresh');
		   
			 }
			    $data['search_term'] = $term;
			    $data['title'] = 'Search Query';
			    $data['main']  = 'public/search';
				$this->load->view('templates/template_home', $data);
		  
		  
		  }else{
			  
			     redirect("home");
			  
			  }
			    
   }
   
   
   
}//end of class