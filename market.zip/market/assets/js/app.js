// JavaScript Document





//this blocks of code validates the register inputs
$('#form-register').on('submit',function(e){
	
 	//this method validate register form
	validate_register(e)

 });
 
 
 
 
 //this blocks of code validates the login inputs
$('#form_login').on('submit',function(e){
	
	//caling validates function for login
	validate_login(e);
	
 });
 
 
 
 //this blocks of code validates
 $('#form-step-first').on('submit', function(e){
	  
	  //this method validates step_1 post ads
	  validate_step_1(e)
	 
  });
 
 
 
 
 
$('#location').on('change', function(e){
	
	//this method show form for upload
	show_upload_form(e);
	
 });
 
 
 $('#form-step-second').on('submit', function(e){
	
	
	
  if($('#file').val()===''){
	  
	  e.preventDefault();
	  $('#feedback_upload_foto').html('<div class="alert alert-danger" role="alert"><i class="fa fa-warning (alias)"></i> You did Not Select Any Image</div>');
	  
	  
	  }else{
		  
	 var form = $(this);
	var formdata = new FormData($(this)[0]);
	e.preventDefault();
	
	$.ajax({
		
		url:form.attr('action'),
		method:form.attr('method'),
		data: formdata,
		contentType: false,
		cache:false,
		processData:false,
		//async:false,
		success: function(data){
			   
			  if(data === 'error'){
				  
				  }else{
			      
				   console.log(data);
			       $('#feed_back_second_step').html('<div class="alert alert-success" role="alert">'+ data +'</div>');
				   
				   
				   $('#form-step-second').addClass('show_upload_form');
				   $('#option_link').removeClass('show_upload_form');
				  
				  }
			}
		
		});  
		  
		  
		  }
	  
	
	
	 
 });

 
 
 
 /* all functions  */
 
  
 
 
 
 

 
 
 
 function validate_step_1(e)
 {
   
    if($('#product_title').val()==='' || $('#product_desc').val()==='' || $('#price').val()==='' || $('#category').val()==='Choose Category'){
		 
		 e.preventDefault();
		 $('#feedback_step_first').html('<div class="alert alert-danger" role="alert"><i class="fa fa-warning (alias)"></i> please all field are required</div>');
		
      }
    
 }
 
 
 
 
 
 //this method validates login
 function validate_login(e)
 {
    
	if($('#email').val()==='' || $('#password').val()===''){
		
		    e.preventDefault();
			$('#feedback_login').html('<div class="alert alert-danger" role="alert"><i class="fa fa-warning (alias)"></i> please all field are required</div>');
			
		}else{
			   
			   //allowing registration
			
			}
 }
 
 
 //this method validates register
 function validate_register(e)
 { 
   
   if($('#name').val()==='' || $('#email').val()==='' || $('#password').val()===''){
		
		    e.preventDefault();
			$('#feedback_register').html('<div class="alert alert-danger" role="alert"><i class="fa fa-warning (alias)"></i> please all field are required</div>');
			
		}else{
			   
			   //allowing registration
			
			}
	
 }
 
 
 //this blocks of code addsccategory with ajax
  
/*@
 * //this method adds cost into the database
 * using ajax
 */
  
  $('#form_add_category').on('submit', function(e){
	   
	   if($('#category_name').val() === '' || $('#category_desc').val() === ''){
		      
		    e.preventDefault();
		    $('#feedback_add_category').html('<div class="alert alert-danger" role="alert"><i class="fa fa-warning"></i> please all field are required</div>');
			
		  } else{
			    
				e.preventDefault();
				$.ajax({
					
					url : baseURL + 'admin/dashboard/add_category',
					type: 'POST',
					data : {
						
						category_name : $('#category_name').val(),
						category_desc        : $('#category_desc').val()
						
					},
					success: function(data){
						
					   if(data === 'added'){
						      
							  
							  $('#form_add_category').trigger('reset');
							  $('#feedback_add_category').html('<div class="alert alert-success" role="alert"> Category Added Successfuly</div>');
							  setTimeout("$('#modal_add_category').modal('hide')", 3000);
						   
						   
						   }else{
							   
							     $('#feedback_add_category').html('Sorry Error occured');
							   
							   }
					   
					   	
					 }
					
					
					
					});
			    
			  
			  } 
	  
	  
	  
	})
	
	
	
	
	
	function show_product(product_id)
	{    
	     console.log(product_id);
		
		$.ajax({
			  
			  url  : baseURL + 'admin/dashboard/get_unique_product_admin',
			  type : 'POST',
			  data :{product_id:product_id}, 
			  dataType:"json",
			  success: function(data){
				    var image_addr =  baseURL+data.image_url;
				    var img = '';
					
					
					   
						 
						 
				       img +=' <img src="'+image_addr+'" class="product"><br>';
				      
					 
				     $('#image-modal').html(img);
					 
					 
					 
                  
                  
                
					 
					 var details = '';
					    
						  details += '<div class="product_lebel">  ';
						  details += '<h4>'+data.product_title+'</h4>';
						  details += '<h5 class="text-yellow">₦'+data.product_price+'</h5></div>';
					      $('#image-details').html(details);
					 
					 $("#display_product").on("hidden.bs.modal", function(){
						$("#image-modal").html("");
						$('#image-details').html("");
					});
				  
				  }
			
			
			});
		
    }
	
	
	
   //this function validates the search area in the home page
   $('#form-search-term').on('submit', function(e){
	   
	   if($('#term').val()===''){
		   
		      e.preventDefault();
			  $('#term').addClass('error'); 
		   
		   }
	   
	 });
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 	
	